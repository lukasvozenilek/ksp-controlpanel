Readme
=

[Building](https://github.com/richardbunt/Telemachus/wiki/Building)

[KSP Forum Thread](http://forum.kerbalspaceprogram.com/threads/24594)

[Installation](https://github.com/richardbunt/Telemachus/wiki/Installation)

[User Guide](https://github.com/richardbunt/Telemachus/wiki/User-Guide)
